package com.example.market

data class Type(val Type:String)
