package com.example.market

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class Login : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    // [END declare_auth]

    private var customToken: String? = null
    lateinit var email: EditText
    lateinit var password: EditText
    lateinit var main: Intent
    lateinit var reg: Intent
    lateinit var loginn: Button
    lateinit var regis: TextView

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        email= findViewById<EditText>(R.id.fstnme)
        password= findViewById<EditText>(R.id.Password)
        main = Intent(this, MainActivity::class.java)
        loginn= findViewById<Button>(R.id.loginbtn)
        reg = Intent(this, Register::class.java)
        regis= findViewById<Button>(R.id.Return)
        // [START initialize_auth]
        // Initialize Firebase Auth
        auth = Firebase.auth
        // [END initialize_auth]
        loginn.setOnClickListener {
            if(password.text.isEmpty()){
                password.setError("Enter your password")
            }
            if(email.text.isEmpty()){
                email.setError("Enter your email")
            }
            if(!email.text.isEmpty()&&!password.text.isEmpty()){
                startSignIn()

            }
        }
        regis.setOnClickListener { startActivity(reg) }
    }

    // Initiate sign in with custom token
    public fun startSignIn() {
        // Initiate sign in with custom token
        // [START sign_in_custom]
//            customToken?.let {

        auth.signInWithEmailAndPassword(email.text.toString(), password.text.toString())
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    // Log.d(Register.TAG, "signInWithEmailAndPassword:success")
                    val user = auth.currentUser
                    Toast.makeText(this,"Let's Start", Toast.LENGTH_SHORT).show()
                    updateUI(user)
                    startActivity(main)
                } else {
                    // If sign in fails, display a message to the user.
                    //   Log.w(Register.TAG, "signInWithEmailAndPassword:failure", task.exception)
                    Toast.makeText(this,"invalid email or password", Toast.LENGTH_SHORT).show()
                    updateUI(null)
                }
//                   }
            }
        // [END sign_in_custom]
    }
    // [END sign_in_custom]


    private fun updateUI(user: FirebaseUser?) {

    }

    companion object {
        private const val TAG = "CustomAuthActivity"
    }

}


