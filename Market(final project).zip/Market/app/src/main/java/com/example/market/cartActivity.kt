package com.example.market

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.tasks.OnFailureListener
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class cartActivity : AppCompatActivity() {
    val database: DatabaseReference = FirebaseDatabase.getInstance().getReference()
    lateinit var adapter: CardAdapter
    lateinit var recyclervieww: RecyclerView
    lateinit var data:ArrayList<ItemsViewModel>
    lateinit var order: Button
    lateinit var ret: Intent


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)
        recyclervieww = findViewById<RecyclerView>(R.id.recyclerviewww)
        recyclervieww.layoutManager = LinearLayoutManager(this)
        order=findViewById(R.id.ordr)
        ret= Intent(this, MapsActivity::class.java)


        data = ArrayList<ItemsViewModel>()

        getItemsData()
        order.setOnClickListener{
            startActivity(ret)
        }


    }

    private fun getItemsData() {
        val currentuser = FirebaseAuth.getInstance().currentUser!!.uid
        database.child("carts").child(currentuser).get().addOnSuccessListener {
            it.children.forEach({
                data.add(ItemsViewModel(
                    it.key.toString(),
                    it.child("image").value.toString(),
                    it.child("text").value.toString(),
                    it.child("text2").value.toString(),
                    it.child("text3").value.toString()
                ))
                //Toast.makeText(this, "${it.key.toString()}", Toast.LENGTH_SHORT).show()


            })
            adapter = CardAdapter(data)
            recyclervieww.adapter = adapter
        }.addOnFailureListener(OnFailureListener {
            Toast.makeText(this, "Error in database: ${it.message}", Toast.LENGTH_SHORT).show()
        })



    }
}