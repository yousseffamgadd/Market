package com.example.market

data class ItemsViewModel(val id:String,val image: String, val text: String, val text2: String, val text3: String)
