package com.example.market

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class Register : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    // [END declare_auth]

    private var customToken: String? = null
    lateinit var email: EditText
    lateinit var password: EditText
    lateinit var select: Intent
    lateinit var loginn: Intent
    lateinit var Phone: EditText
    lateinit var namee: EditText
    lateinit var login: TextView
    lateinit var register: Button



    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)



        email= findViewById<EditText>(R.id.fstnme)
        password= findViewById<EditText>(R.id.Password)
        Phone= findViewById<EditText>(R.id.Phone)
        namee= findViewById<EditText>(R.id.Name)
        register= findViewById<Button>(R.id.registerbuy)

        login= findViewById<TextView>(R.id.login)
        select = Intent(this, Selection::class.java)
        loginn = Intent(this, Login::class.java)
        // [START initialize_auth]
        // Initialize Firebase Auth
        auth = Firebase.auth
        // [END initialize_auth]

        register.setOnClickListener {
            if(namee.text.isEmpty()){
                namee.setError("Enter your name")
            }
            if(password.text.isEmpty()){
                password.setError("Enter your password")
            }
            if(email.text.isEmpty()){
                email.setError("Enter your email")
            }
            if(Phone.text.isEmpty()){
                Phone.setError("Retype your Password")
            }
            if(password.length()<6){
                password.setError("Enter at least 6 characters")
            }
            if(Phone.text.toString()!=password.text.toString()){
                Phone.setError("Passwords are not the same")
            }
            if(password.text.length>=6&&!namee.text.isEmpty()&&!email.text.isEmpty()&&!password.text.isEmpty()&&!Phone.text.isEmpty()
                &&Phone.text.toString()==password.text.toString()){

                startSignIn()


            }

        }





        login.setOnClickListener { startActivity(loginn) }

    }


    public override fun onStart() {
        super.onStart()
        // Check if user is signed in (non-null) and update UI accordingly.
        val currentUser = auth.currentUser
        updateUI(currentUser)
    }
    // [END on_start_check_user]

    private fun startSignIn() {
        // Initiate sign in with custom token
        // [START sign_in_custom]
        //  customToken?.let {

        auth.createUserWithEmailAndPassword(email.text.toString(), password.text.toString())
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {

                    val user = auth.currentUser
                    Toast.makeText(this,"User created", Toast.LENGTH_SHORT).show()
                    updateUI(user)
                    startActivity(select)
                } else {
                    // If sign in fails, display a message to the user.
                    // Log.w(TAG, "signInWithEmailAndPassword:failure", task.exception)
                    Toast.makeText(this,"invalid email or password", Toast.LENGTH_SHORT).show()
                    updateUI(null)

                }
                //  }
            }
        // [END sign_in_custom]
    }

    private fun updateUI(user: FirebaseUser?) {

    }

}


