package com.example.market

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class CardAdapter (private val mList: List<ItemsViewModel>) : RecyclerView.Adapter<CardAdapter.ViewHolder>() {

    // create new views
    private var database: DatabaseReference = FirebaseDatabase.getInstance().getReference()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // inflates the card_view_design view
        // that is used to hold list item
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.cartcardview, parent, false)

        return ViewHolder(view)
    }

    // binds the list items to a view
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val ItemsViewModel = mList[position]


        Glide.with(holder.imageVieww.context)
            .load(ItemsViewModel.image)
            .into(holder.imageVieww)
        holder.priceee.text=ItemsViewModel.text2
        holder.countt.text=ItemsViewModel.text3
        holder.namee.text = ItemsViewModel.text

        val x=Integer.parseInt(holder.countt.text.toString())
        val y=Integer.parseInt(holder.priceee.text.toString())
        val z=x*y
        holder.totl.text=z.toString()
    }

    // return the number of the items in the list
    override fun getItemCount(): Int {
        return mList.size
    }

    // Holds the views for adding it to image and text
    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val imageVieww: ImageView = itemView.findViewById(R.id.imageviewww)
        val namee: TextView = itemView.findViewById(R.id.Nameee)
        val priceee: TextView =itemView.findViewById(R.id.Priceeee)
        val countt: TextView = itemView.findViewById(R.id.Counttt)
        val totl: TextView = itemView.findViewById(R.id.Totalll)
    }
}
