package com.example.market

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.google.android.gms.tasks.OnFailureListener
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class MainActivity : AppCompatActivity() {
    lateinit var googlemaps: Intent
    lateinit var information: Intent
    lateinit var cart2: Intent
    lateinit var cart3: Intent
    lateinit var VOIP2: Intent
    lateinit var database: DatabaseReference
    lateinit var maps: Button
    lateinit var info: Button
    lateinit var cartt: Button
    lateinit var VOIP: Button

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        database= FirebaseDatabase.getInstance().getReference()
        maps = findViewById<Button>(R.id.mapsbtn)

        val currentuser = FirebaseAuth.getInstance().currentUser!!.uid
        cartt = findViewById<Button>(R.id.cart)
        VOIP= findViewById<Button>(R.id.VOIP)
        cart2 = Intent(this, Recycleview::class.java)
        cart3 = Intent(this, Seller::class.java)
        VOIP2 = Intent(this, Voice::class.java)
        googlemaps = Intent(this, MapsActivity::class.java)




        maps.setOnClickListener { startActivity(googlemaps) }

       VOIP.setOnClickListener { startActivity(VOIP2) }
        cartt.setOnClickListener {
             database.child("Type").child(currentuser).get().addOnSuccessListener {

            val Itstype = it.child("type").value.toString()
            if(Itstype=="Buyer"){
                startActivity(cart2)

            }
            else if(Itstype=="Seller"){
                startActivity(cart3)
            }



    }.addOnFailureListener(OnFailureListener { })

        }


    }
}