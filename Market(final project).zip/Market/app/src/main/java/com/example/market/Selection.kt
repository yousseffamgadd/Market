package com.example.market

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.google.android.gms.tasks.OnFailureListener
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class Selection : AppCompatActivity() {
    lateinit var buyer : Button
    lateinit var seller : Button
    lateinit var database : DatabaseReference
    lateinit var main : Intent
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_selection)
        buyer=findViewById(R.id.buyerbtn)
        seller=findViewById(R.id.sellerbtn)
        val currentuser = FirebaseAuth.getInstance().currentUser!!.uid
        database = FirebaseDatabase.getInstance().getReference()
        main = Intent(this, MainActivity::class.java)
        buyer.setOnClickListener {
            val ref = database.child("Type").child(currentuser)

            ref.setValue(Type( "Buyer")).addOnSuccessListener {
            }.addOnFailureListener(OnFailureListener {})
            startActivity(main)
        }
        seller.setOnClickListener {
            val ref = database.child("Type").child(currentuser)

            ref.setValue(Type( "Seller")).addOnSuccessListener {
            }.addOnFailureListener(OnFailureListener {})
            startActivity(main)

        }
    }


}