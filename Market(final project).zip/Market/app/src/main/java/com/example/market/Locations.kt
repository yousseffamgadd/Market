package com.example.market

data class Locations(val lat:String,val lon:String)
