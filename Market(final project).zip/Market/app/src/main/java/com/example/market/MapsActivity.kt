package com.example.market

import android.content.pm.PackageManager
import android.location.Location
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.lifecycle.Transformations.map
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.example.market.databinding.ActivityMapsBinding
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.GoogleMap.OnMarkerClickListener
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.tasks.OnFailureListener
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.maps.android.SphericalUtil

class MapsActivity : AppCompatActivity(), OnMapReadyCallback,OnMarkerClickListener {
    private var database: DatabaseReference = FirebaseDatabase.getInstance().getReference()
    private lateinit var binding: ActivityMapsBinding
    private lateinit var floc: FusedLocationProviderClient
    lateinit var data: ArrayList<Locations>
    private lateinit var myloc: Location
    private var distance: Double = 0.0
    private lateinit var selectedshop: LatLng


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //floc= LocationServices.getFusedLocationProviderClient(this)

        val map = supportFragmentManager.findFragmentById(R.id.map)
                as SupportMapFragment
        map.getMapAsync(this)


    }


    override fun onMapReady(GoogleMap: GoogleMap) {
        val currentuser = FirebaseAuth.getInstance().currentUser!!.uid


        database.child("Locations").get().addOnSuccessListener {
            it.children.forEach({
                val lats = it.child("lat").value.toString().toDouble()
                val longs = it.child("lon").value.toString().toDouble()
                val locations = LatLng(lats, longs)
                val markeroption = MarkerOptions().position(locations).title("Supermarket")
                GoogleMap.moveCamera(CameraUpdateFactory.newLatLng(locations))
                GoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(locations, 7f))
                GoogleMap.addMarker(markeroption)
                GoogleMap.setOnMarkerClickListener(this)
    database.child("Buyer Location").child(currentuser).get().addOnSuccessListener {
        it.children.forEach({
            val latis = it.child("lat").value.toString().toDouble()
            val longis = it.child("lon").value.toString().toDouble()
            val buyerloc = LatLng(latis, longis)
            val markeroption1 = MarkerOptions().position(buyerloc).title("Your Location")
            GoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(buyerloc, 7f))
            GoogleMap.addMarker(markeroption1)

        })
    }.addOnFailureListener(OnFailureListener {
        Toast.makeText(this, "Error in database: ${it.message}", Toast.LENGTH_SHORT).show()
    })


            })

        }.addOnFailureListener(OnFailureListener {
            Toast.makeText(this, "Error in database: ${it.message}", Toast.LENGTH_SHORT).show()
        })

    }


    override fun onMarkerClick(p0: Marker): Boolean {
        val currentuser = FirebaseAuth.getInstance().currentUser!!.uid
        selectedshop = p0.position
        database.child("Buyer Location").child(currentuser).get().addOnSuccessListener {
            it.children.forEach({
                val latis = it.child("lat").value.toString().toDouble()
                val longis = it.child("lon").value.toString().toDouble()
                val buyerloc = LatLng(latis, longis)

                distance = SphericalUtil.computeDistanceBetween(buyerloc, selectedshop)
                Toast.makeText(
                    this, "Distance to this Supermarket is \n "
                            + String.format("%.2f", distance / 1000) + "km and it will cost "+ String.format("%.2f", distance / 100)+" EGP",
                    Toast.LENGTH_SHORT
                ).show()
            })
        }.addOnFailureListener(OnFailureListener {
            Toast.makeText(this, "Error in database: ${it.message}", Toast.LENGTH_SHORT).show()
        })

     return false
    }
}
