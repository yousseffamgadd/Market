package com.example.market


import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.tasks.OnFailureListener
import com.google.android.gms.tasks.OnSuccessListener
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.UploadTask


class Seller : AppCompatActivity() {
    private var database: DatabaseReference = FirebaseDatabase.getInstance().getReference()
    lateinit var pickedPhoto: Uri
    lateinit var Priceprod: EditText
    lateinit var Prodname: EditText
    lateinit var Prodquan: EditText
    lateinit var submit: Button
    lateinit var img: ImageView
    lateinit var main: Intent
    lateinit var total: TextView
    lateinit var addloc:Button
    lateinit var lng: EditText
    lateinit var lat: EditText
    lateinit var imageUrl : Uri
    private var storageReference: StorageReference =
        FirebaseStorage.getInstance().reference.child("images")

    val REQ: Int = 1000



    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_seller)
        submit = findViewById<Button>(R.id.Submit)
        Prodname = findViewById<EditText>(R.id.prodname)
        lng=findViewById<EditText>(R.id.lng)
        lat=findViewById<EditText>(R.id.lat)
        addloc=findViewById(R.id.Addloc)
        Priceprod = findViewById<EditText>(R.id.prodprice)
        Prodquan = findViewById<EditText>(R.id.quantity)
        img = findViewById<ImageView>(R.id.imagegal)

        main = Intent(this, MainActivity::class.java)
        img.setOnClickListener {
            val galleryIntext =
                Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(galleryIntext, REQ)
        }

        addloc.setOnClickListener {
            if(lng.text.toString().isEmpty() || lat.text.toString().isEmpty()){
                addloc.setError("Enter your location")
            }else{
                uploadLocationToDatabase()
              lng.visibility=View.INVISIBLE
              lat.visibility=View.INVISIBLE
                addloc.visibility=View.INVISIBLE
            }
        }


        submit.setOnClickListener {
            if(Prodquan.text.toString().isNotEmpty() || Prodname.text.toString().isNotEmpty()
                || Priceprod.text.toString().isNotEmpty()){

            storageReference.child("${Prodname.text.toString()}" ).putFile(pickedPhoto)
                .addOnSuccessListener(
                    OnSuccessListener<UploadTask.TaskSnapshot> { taskSnapshot ->
                        taskSnapshot.storage.downloadUrl.addOnSuccessListener {
                            imageUrl = it
                            uploadToDatabase()

                        }
                    })

                ?.addOnFailureListener(OnFailureListener { e ->
                    print(e.message)
                })


            startActivity(main)

        }else{
            submit.setError("Insert Product info")
            }
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, dataa: Intent?) {
        super.onActivityResult(requestCode, resultCode, dataa)
        if (requestCode == REQ && resultCode == Activity.RESULT_OK && dataa != null) {
            pickedPhoto = dataa.data!!
            img.setImageURI(pickedPhoto)
        }

    }



    private fun uploadToDatabase() {
        val currentuser = FirebaseAuth.getInstance().currentUser!!.uid
        val ref = database.child("products").push()
        val user = ItemsViewModel(ref.key.toString(),imageUrl.toString(), Prodname.text.toString(), Priceprod.text.toString(),Prodquan.text.toString())
        ref.setValue(user).addOnSuccessListener {
            Toast.makeText(this, "Data Uploaded...", Toast.LENGTH_SHORT).show()
        }.addOnFailureListener(OnFailureListener {
            Toast.makeText(this, "Error in database: ${it.message}", Toast.LENGTH_SHORT).show()
        })

    }
    private fun uploadLocationToDatabase() {
        val currentuser = FirebaseAuth.getInstance().currentUser!!.uid
        val ref = database.child("Locations")

        ref.push().setValue(Locations( lat.text.toString(),lng.text.toString())).addOnSuccessListener {
            Toast.makeText(this, "Data Uploaded...", Toast.LENGTH_SHORT).show()
        }.addOnFailureListener(OnFailureListener {
            Toast.makeText(this, "Error in database: ${it.message}", Toast.LENGTH_SHORT).show()
        })


    }
}



