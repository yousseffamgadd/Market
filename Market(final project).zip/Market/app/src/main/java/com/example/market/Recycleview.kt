package com.example.market

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.tasks.OnFailureListener
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class Recycleview : AppCompatActivity() {

    lateinit var database: DatabaseReference
    lateinit var adapter: CustomAdapter
    lateinit var recyclerview: RecyclerView
    lateinit var data:ArrayList<ItemsViewModel>
    lateinit var cart: Button
    lateinit var cartactiv:Intent
    lateinit var addloc: Button
    lateinit var longi: EditText
    lateinit var lati: EditText




    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recycleview)
        cartactiv= Intent(this, cartActivity::class.java)
        cart=findViewById<Button>(R.id.Addcart)
        addloc=findViewById<Button>(R.id.locadd)
        longi=findViewById<EditText>(R.id.latitude)
        lati=findViewById<EditText>(R.id.longitude)
        database = FirebaseDatabase.getInstance().getReference()
        recyclerview = findViewById<RecyclerView>(R.id.recyclerview)
        recyclerview.layoutManager = LinearLayoutManager(this)



        data = ArrayList<ItemsViewModel>()
        getItemsData()

        cart.setOnClickListener{
            startActivity(cartactiv)
        }

        addloc.setOnClickListener {
            if(longi.text.toString().isEmpty()|| lati.text.toString().isEmpty()){
                addloc.setError("Enter your location")
            }else{
                uploadLocationToDatabase()
                longi.visibility= View.INVISIBLE
                lati.visibility=View.INVISIBLE
                addloc.visibility=View.INVISIBLE
            }
        }


    }


    private fun uploadLocationToDatabase() {
        val currentuser = FirebaseAuth.getInstance().currentUser!!.uid
        val ref = database.child("Buyer Location").child(currentuser)

        ref.push().setValue(Locations( lati.text.toString(),longi.text.toString())).addOnSuccessListener {
            Toast.makeText(this, "Data Uploaded...", Toast.LENGTH_SHORT).show()
        }.addOnFailureListener(OnFailureListener {
            Toast.makeText(this, "Error in database: ${it.message}", Toast.LENGTH_SHORT).show()
        })


    }


    private fun getItemsData() {
        val currentuser = FirebaseAuth.getInstance().currentUser!!.uid
        database.child("products").get().addOnSuccessListener {
            it.children.forEach({
                data.add(ItemsViewModel(
                    it.key.toString(),
                    it.child("image").value.toString(),
                    it.child("text").value.toString(),
                    it.child("text2").value.toString(),
                    it.child("text3").value.toString()
                ))



            })
            adapter = CustomAdapter(data)
            recyclerview.adapter = adapter
        }.addOnFailureListener(OnFailureListener {
            Toast.makeText(this, "Error in database: ${it.message}", Toast.LENGTH_SHORT).show()
        })



    }

}



