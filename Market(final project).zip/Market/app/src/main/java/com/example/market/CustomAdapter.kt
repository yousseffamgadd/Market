package com.example.market

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.bumptech.glide.Glide
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.tasks.OnFailureListener
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class CustomAdapter(private val mList: List<ItemsViewModel>) : RecyclerView.Adapter<CustomAdapter.ViewHolder>() {
    var c: Int = 0
    var p :Int=0
    var g:Int=0
    var f:Int=0

    private var database: DatabaseReference = FirebaseDatabase.getInstance().getReference()

    // create new views
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.card_view_design, parent, false)

        return ViewHolder(view)

    }

    // binds the list items to a view
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val ItemsViewModel = mList[position]


        Glide.with(holder.imageView.context)
            .load(ItemsViewModel.image)
            .into(holder.imageView);
        holder.textView.text = ItemsViewModel.text
        holder.pricee.text=ItemsViewModel.text2
        holder.quant.text=ItemsViewModel.text3



        holder.pluss.setOnClickListener {
            val currentuser = FirebaseAuth.getInstance().currentUser!!.uid
            database.child("products").get().addOnSuccessListener {
                it.children.forEach({
                    if(it.key== ItemsViewModel.id){
                        val prodId = it.key

                        database.child("carts").child(currentuser).child(ItemsViewModel.id)
                            .setValue(ItemsViewModel(
                                prodId.toString(),
                                ItemsViewModel.image,
                                ItemsViewModel.text,
                                ItemsViewModel.text2,
                                ((Integer.parseInt(ItemsViewModel.text3)-(Integer.parseInt(ItemsViewModel.text3)-Integer.parseInt(holder.countt.text.toString())))).toString())).addOnCompleteListener({
                                database.child("products").child(prodId.toString())
                                    .child("text3").setValue((Integer.parseInt(ItemsViewModel.text3)-Integer.parseInt(holder.countt.text.toString())).toString())
                            }).addOnFailureListener({})



                    }
                })

            }.addOnFailureListener(OnFailureListener {
                Toast.makeText(holder.pricee.context, "Error in database: ${it.message}", Toast.LENGTH_SHORT).show()
            })
            g=Integer.parseInt(holder.pricee.text.toString())
            c =  Integer.parseInt(holder.countt.text.toString())
            f=Integer.parseInt(holder.quant.text.toString())
            if (c>=f){
                holder.countt.setError("can't be larger than quantity")
            }else{
                c=c+1
                holder.countt.setText(c.toString())
                p=Integer.parseInt(holder.pricenumber.text.toString())
                p=c*g
                holder.pricenumber.setText(p.toString())

            }
        }
        holder.minuss.setOnClickListener {
            database.child("products").get().addOnSuccessListener {
                it.children.forEach({
                    if(it.key== ItemsViewModel.id){
                        val prodId = it.key
                        val currentuser = FirebaseAuth.getInstance().currentUser!!.uid
                        database.child("carts").child(currentuser).child(ItemsViewModel.id)
                            .setValue(ItemsViewModel(
                                prodId.toString(),
                                ItemsViewModel.image,
                                ItemsViewModel.text,
                                ItemsViewModel.text2,
                                ((Integer.parseInt(ItemsViewModel.text3)-(Integer.parseInt(ItemsViewModel.text3)-Integer.parseInt(holder.countt.text.toString())))).toString())).addOnCompleteListener({
                                database.child("products").child(prodId.toString())
                                    .child("text3").setValue((Integer.parseInt(ItemsViewModel.text3)-Integer.parseInt(holder.countt.text.toString())).toString())
                            }).addOnFailureListener({})



                    }
                })

            }.addOnFailureListener(OnFailureListener {
                Toast.makeText(holder.pricee.context, "Error in database: ${it.message}", Toast.LENGTH_SHORT).show()
            })
            g=Integer.parseInt(holder.pricee.text.toString())
            c =  Integer.parseInt(holder.countt.text.toString())
            if (c==0){
                holder.countt.setError("can't be Smaller than 0")
            }
            else {
                c = c - 1
                holder.countt.setText(c.toString())
                p = Integer.parseInt(holder.pricenumber.text.toString())
                p = c * g
                holder.pricenumber.setText(p.toString())


            }
        }

    }

    // return the number of the items in the list
    override fun getItemCount(): Int {
        return mList.size
    }

    // Holds the views for adding it to image and text
    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val imageView: ImageView = itemView.findViewById(R.id.imageview)
        val textView: TextView = itemView.findViewById(R.id.textView)
        val pricee: TextView =itemView.findViewById(R.id.price)
        val pluss: Button = itemView.findViewById(R.id.Plusbtn)
        val minuss: Button = itemView.findViewById(R.id.Minusbtn)
        val countt: TextView = itemView.findViewById(R.id.count)
        val pricenumber: TextView = itemView.findViewById(R.id.pxn)
        val quant: TextView = itemView.findViewById(R.id.quan)


    }

}
